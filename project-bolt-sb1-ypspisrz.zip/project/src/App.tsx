import React, { useState, useEffect } from 'react';
import { Search, Bell, BookOpen, MessageSquare, ThumbsUp, Share2, Bookmark, Moon, Sun } from 'lucide-react';

function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');

  const blogPosts = [
    {
      id: 1,
      title: "The Future of Web Development: What's Next in 2025",
      excerpt: "Exploring the latest trends and technologies shaping the future of web development, from AI-powered tools to WebAssembly innovations.",
      author: "Sarah Chen",
      date: "Mar 15, 2024",
      readTime: "8 min read",
      image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&q=80&w=2072",
      category: "Technology"
    },
    {
      id: 2,
      title: "Sustainable Architecture: Building for Tomorrow",
      excerpt: "How modern architects are incorporating eco-friendly practices and sustainable materials in their innovative designs.",
      author: "Michael Torres",
      date: "Mar 14, 2024",
      readTime: "6 min read",
      image: "https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&q=80&w=2072",
      category: "Architecture"
    },
    {
      id: 3,
      title: "The Rise of Digital Nomads in Post-Pandemic Era",
      excerpt: "Understanding the growing trend of location-independent professionals and how they're reshaping the global workforce.",
      author: "Emma Watson",
      date: "Mar 13, 2024",
      readTime: "5 min read",
      image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=2070",
      category: "Lifestyle"
    }
  ];

  const [posts, setPosts] = useState(blogPosts.map(post => ({
    ...post,
    likes: 2500,
    liked: false,
    bookmarked: false
  })));

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const categories = ['All', 'Technology', 'Architecture', 'Lifestyle'];

  const handleLike = (postId: number) => {
    setPosts(posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          likes: post.liked ? post.likes - 1 : post.likes + 1,
          liked: !post.liked
        };
      }
      return post;
    }));
  };

  const handleBookmark = (postId: number) => {
    setPosts(posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          bookmarked: !post.bookmarked
        };
      }
      return post;
    }));
  };

  const filteredPosts = posts.filter(post => {
    const matchesCategory = selectedCategory === 'All' || post.category === selectedCategory;
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className={`min-h-screen ${darkMode ? 'dark bg-gray-900' : 'bg-gray-50'} transition-colors duration-200`}>
      {/* Header */}
      <header className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white'} shadow-sm fixed w-full z-10 transition-colors duration-200`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <BookOpen className={`h-8 w-8 ${darkMode ? 'text-blue-400' : 'text-blue-600'}`} />
              <h1 className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>BlogVerse</h1>
            </div>
            <div className="flex items-center space-x-6">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search articles..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className={`w-64 pl-10 pr-4 py-2 border rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                    darkMode ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400' : 'bg-white border-gray-300 text-gray-900'
                  }`}
                />
                <Search className="h-5 w-5 text-gray-400 absolute left-3 top-2.5" />
              </div>
              <button
                onClick={() => setDarkMode(!darkMode)}
                className={`p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors`}
              >
                {darkMode ? (
                  <Sun className="h-5 w-5 text-yellow-500" />
                ) : (
                  <Moon className="h-5 w-5 text-gray-600" />
                )}
              </button>
              <Bell className={`h-6 w-6 ${darkMode ? 'text-gray-300 hover:text-blue-400' : 'text-gray-600 hover:text-blue-600'} cursor-pointer transition-colors`} />
              <img
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
                alt="Profile"
                className="h-8 w-8 rounded-full cursor-pointer"
              />
            </div>
          </div>
        </div>
      </header>

      {/* Category Filter */}
      <div className="pt-24 pb-4 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex space-x-4 overflow-x-auto pb-2">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                selectedCategory === category
                  ? 'bg-blue-600 text-white'
                  : `${darkMode ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-600 hover:bg-gray-200'}`
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPosts.map((post) => (
            <article key={post.id} className={`${darkMode ? 'bg-gray-800' : 'bg-white'} rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1`}>
              <img
                src={post.image}
                alt={post.title}
                className="h-48 w-full object-cover"
              />
              <div className="p-6">
                <span className={`text-sm font-medium ${darkMode ? 'text-blue-400' : 'text-blue-600'}`}>{post.category}</span>
                <h2 className={`mt-2 text-xl font-semibold ${darkMode ? 'text-white' : 'text-gray-900'} line-clamp-2`}>
                  {post.title}
                </h2>
                <p className={`mt-3 ${darkMode ? 'text-gray-300' : 'text-gray-600'} line-clamp-3`}>
                  {post.excerpt}
                </p>
                <div className="mt-4 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <img
                      src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
                      alt={post.author}
                      className="h-8 w-8 rounded-full"
                    />
                    <div>
                      <p className={`text-sm font-medium ${darkMode ? 'text-white' : 'text-gray-900'}`}>{post.author}</p>
                      <div className="flex space-x-2 text-sm text-gray-500">
                        <span>{post.date}</span>
                        <span>·</span>
                        <span>{post.readTime}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="mt-4 flex items-center space-x-4 text-gray-500">
                  <button
                    onClick={() => handleLike(post.id)}
                    className={`flex items-center space-x-1 transition-colors ${
                      post.liked
                        ? 'text-blue-600'
                        : `${darkMode ? 'text-gray-400 hover:text-blue-400' : 'hover:text-blue-600'}`
                    }`}
                  >
                    <ThumbsUp className={`h-5 w-5 ${post.liked ? 'fill-current' : ''}`} />
                    <span>{post.likes.toLocaleString()}</span>
                  </button>
                  <button className={`flex items-center space-x-1 ${darkMode ? 'text-gray-400 hover:text-blue-400' : 'hover:text-blue-600'}`}>
                    <MessageSquare className="h-5 w-5" />
                    <span>42</span>
                  </button>
                  <button className={`flex items-center space-x-1 ${darkMode ? 'text-gray-400 hover:text-blue-400' : 'hover:text-blue-600'}`}>
                    <Share2 className="h-5 w-5" />
                  </button>
                  <button
                    onClick={() => handleBookmark(post.id)}
                    className={`ml-auto transition-colors ${
                      post.bookmarked
                        ? 'text-blue-600'
                        : `${darkMode ? 'text-gray-400 hover:text-blue-400' : 'hover:text-blue-600'}`
                    }`}
                  >
                    <Bookmark className={`h-5 w-5 ${post.bookmarked ? 'fill-current' : ''}`} />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </main>
    </div>
  );
}

export default App;